package com.example.exer5daetkentmer;

public class Model {
    private String id,description,title;
    public Model(){

    }

    public Model(String id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
    }

    public String getId(){return  id;}

    public void setId(String id){this.id = id;}

    public String getDescription(){return description;}

    public void setDescription(String description){this.description = description;}

    public String getTitle(){return title;}

    public void setTitle(String title){this.title = title;}

    @Override
    public String toString(){
        return  "Model{" + "id='" + id + '\'' + ", description='" + description +
                '\'' + ", title='" + title + '\'' + '}';
    }
}

